%source https://www.mathworks.com/help/nnet/examples/visualize-activations-of-a-convolutional-neural-network.html
net1 = xceptionsDFU;
net1.Layers
% analyzeNetwork(net)
%%
im=imread('6.jpg');
 im = imresize(im,[299,299]); 
%   im1 = cat(3, im, im, im);
 imgSize = size(im);
imgSize = imgSize(1:2);
 %%   
    act1 = activations(net1,im,'block1_conv1','OutputAs','channels');
    sz = size(act1);
act1 = reshape(act1,[sz(1) sz(2) 1 sz(3)]);
montage(mat2gray(act1),'Size',[4 8])
%       colormap(jet);   
% ConvQ1  convInp
%%
act1ch32 = act1(:,:,:,24);
act1ch32 = mat2gray(act1ch32);
act1ch32 = imresize(act1ch32,imgSize);
imshowpair(im,act1ch32,'montage')
colormap(jet);
%%
[maxValue,maxValueIndex] = max(max(max(act1)));
act1chMax = act1(:,:,:,maxValueIndex);
act1chMax = mat2gray(act1chMax);
act1chMax = imresize(act1chMax,imgSize);
imshowpair(im,act1chMax,'montage')
colormap(jet);
%%
act5 = activations(net1,im,'convInp','OutputAs','channels');
sz = size(act5);
act5 = reshape(act5,[sz(1) sz(2) 1 sz(3)]);
montage(imresize(mat2gray(act5),[4 4]))
%   colormap(jet);
%%
[maxValue5,maxValueIndex5] = max(max(max(act5)));
act5chMax = act5(:,:,:,maxValueIndex5);
imshow(imresize(mat2gray(act5chMax),imgSize))
%   colormap(jet);
%%
montage(imresize(mat2gray(act5(:,:,:,[3 5])),imgSize))
%%
act5relu = activations(net,im,'relu5','OutputAs','channels');
sz = size(act5relu);
act5relu = reshape(act5relu,[sz(1) sz(2) 1 sz(3)]);
montage(imresize(mat2gray(act5relu(:,:,:,[3 5])),imgSize))