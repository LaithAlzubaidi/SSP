% Load the pre-trained network
net = xceptionTLbigFingerV3;



% Define the input and output folders
inputFolder = 'C:\Users\ALZUBAID\OneDrive - Queensland University of Technology\Desktop\New-Orthopedics\Pattren-Recognision\Finger-Done\Grad-Xception\N'; % Replace with the path to the input images folder
outputFolder = 'C:\Users\ALZUBAID\OneDrive - Queensland University of Technology\Desktop\New-Orthopedics\Pattren-Recognision\Finger-Done\Grad-Xception\N-Grad'; % Replace with the path to the output images folder


% Get a list of all image files in the input folder
imageFiles = dir(fullfile(inputFolder, '*.png')); % Update the file extension if needed

% Loop over each image
for i = 1:numel(imageFiles)
    % Read the image
    imagePath = fullfile(inputFolder, imageFiles(i).name);
    X = imread(imagePath);
   
    % Resize the image to match the network's input size
    inputSize = net.Layers(1).InputSize(1:2);
    X = imresize(X, inputSize);
   
    % Classify the image
    label = classify(net, X);
   
    % Generate the heatmap using Grad-CAM
    scoreMap = gradCAM(net, X, label);
   
    % Display the original image with the heatmap
    figure
    imshow(X)
    hold on
    imagesc(scoreMap, 'AlphaData', 0.5)
    colormap jet
   
    % Add the predicted label on top of the heatmap
    text(10, 10, char(label), 'Color', 'yellow', 'FontWeight', 'bold')
   
    % Save the image with the heatmap and label in the output folder
    [~, imageName, ~] = fileparts(imageFiles(i).name);
    outputFileName = fullfile(outputFolder, [imageName '_heatmap.jpg']);
    saveas(gcf, outputFileName);
   
    % Close the figure
    close;
end



