%% Load 
A= 'C:\Users\ALZUBAID\OneDrive - Queensland University of Technology\Desktop\New-Orthopedics\Finger-Done';
parentDir = A;
 dataDir = 'Train';
% dataDir = 'TargetDataS';



%%  Divide into Training and Validation Data

allImages = imageDatastore(fullfile(parentDir,dataDir),...
    'IncludeSubfolders',true,...
    'LabelSource','foldernames');
 allImages.ReadFcn = @customReadDatastoreImage;
disp(['Number of allImages: ',num2str(numel(allImages.Files))]);

 %% show image from imageDatastore

 img = readimage(allImages,16);
imshow(img)
%%
rng default
[imgsTrain,imgsValidation] = splitEachLabel(allImages,0.90,'randomized');
disp(['Number of training images: ',num2str(numel(imgsTrain.Files))]);

disp(['Number of validation images: ',num2str(numel(imgsValidation.Files))]);

%% load pre-trained network
net = efficientnetTLbig;



%%
net.Layers
%%
lgraph = layerGraph(net);
numberOfLayers = numel(lgraph.Layers);
figure('Units','normalized','Position',[0.1 0.1 0.8 0.8]);
plot(lgraph)
title(['Layer Graph: ',num2str(numberOfLayers),' Layers']);
%% raplace 

numClasses = numel(categories(imgsTrain.Labels));
newConnectedLayer = fullyConnectedLayer(numClasses,'Name','newFinger',...
    'WeightLearnRateFactor',5,'BiasLearnRateFactor',5);
lgraph = replaceLayer(lgraph,'newTLlayer',newConnectedLayer);

newClassLayer = classificationLayer('Name','new_classoutFinger');
lgraph = replaceLayer(lgraph,'new_classoutTLlayerSHUFFLE',newClassLayer);

analyzeNetwork(lgraph)


%% Freeze Initial Layers
layers = lgraph.Layers;
connections = lgraph.Connections;

layers(1:123) = freezeWeights(layers(1:123));
lgraph = createLgraphUsingConnections(layers,connections);
%%
options = trainingOptions('adam',...
    'MiniBatchSize',10,...
    'MaxEpochs',500,...
    'Shuffle','every-epoch', ...
     'InitialLearnRate',3e-4, ...
    'ValidationData',imgsValidation,...
    'ValidationFrequency',10,...
    'Verbose',1,...
    'ExecutionEnvironment','cpu',...
    'Plots','training-progress');
rng default
%%
efficientnetTLbigFinger= trainNetwork(imgsTrain,lgraph,options);

%% SAVE 
save MobilTLbigFinger
%%
[YPred,probs] = classify(xceptionMRITL,imgsValidation);
accuracy = mean(YPred==imgsValidation.Labels);
disp(['Accuracy: ',num2str(100*accuracy),'%'])



%%
function data=customReadDatastoreImage(filename)
% code from default function: 
onState = warning('off', 'backtrace'); 
c = onCleanup(@() warning(onState)); 
data = imread(filename); % added lines: 
data = data(:,:,min(1:3, end)); 
%   data = normalize (data, 'range');
data = imresize(data,[224 224]);

end

%%

%layers = freezeWeights(layers)
function layers = freezeWeights(layers)

for ii = 1:size(layers,1)
    props = properties(layers(ii));
    for p = 1:numel(props)
        propName = props{p};
        if ~isempty(regexp(propName, 'LearnRateFactor$', 'once'))
            layers(ii).(propName) = 0;
        end
    end
end

end


%%
% lgraph = createLgraphUsingConnection
function lgraph = createLgraphUsingConnections(layers,connections)

lgraph = layerGraph();
for i = 1:numel(layers)
    lgraph = addLayers(lgraph,layers(i));
end

for c = 1:size(connections,1)
    lgraph = connectLayers(lgraph,connections.Source{c},connections.Destination{c});
end

end

