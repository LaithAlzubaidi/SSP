%%  classifers Fusion , Laith Alzubaidi
%% Loading the confidence values of classifers from excel sheet 

data1=xlsread('FinalFusion.xlsx','D5:D47');
data2=xlsread('FinalFusion.xlsx','E5:E47');
prob1_S=[data1 data2];

data11=xlsread('FinalFusion.xlsx','G5:G47');
data22=xlsread('FinalFusion.xlsx','H5:H47');
prob2_S=[data11 data22];

% 
data111=xlsread('FinalFusion.xlsx','J5:J47');
data222=xlsread('FinalFusion.xlsx','K5:K47');
prob3_S=[data111 data222];


data1111=xlsread('FinalFusion.xlsx','M5:M47');
data2222=xlsread('FinalFusion.xlsx','N5:N47');
prob4_S=[data1111 data2222];

%% Fusion process


 L=length(prob1_S); % size of the array


A = zeros(L,7); % to store the out values 

 for i = 1:L
       Op_Prob=[prob1_S(i,:);prob2_S(i,:);prob3_S(i,:);prob4_S(i,:)]; % equal weights
     
%     Op_Prob=[prob2_S(i,:);prob3_S(i,:)]; % Two classifiers

%     Op_Prob=[prob1_S(i,:)*0.2;prob2_S(i,:)*0.2;prob3_S(i,:)*0.6]; % priority weights  

 window=Op_Prob;
 
 A_Prod=prod(window);
  
if  A_Prod(2)> A_Prod(1)
    Op_prod = 2;
else
    Op_prod  =  1; 
end

B_sum=sum(window);
if B_sum(2)>B_sum(1)
    OP_sum = 2;
else
    OP_sum  =  1; 
end

C_mean=mean(window);
if C_mean(2)>C_mean(1)
    OP_mean = 2;
else
    OP_mean  =  1; 
end


A_min=min(window);
if A_min(2)>A_min(1)
    OP_min = 2;
else
    OP_min  =  1; 
end

A_max=max(window);
if A_max(2)>A_max(1)
    OP_max = 2;
else
    OP_max =  1; 
end

D_med=median(window); 

if D_med(2)>D_med(1)
    OP_med= 2;
else
    OP_med  =  1; 
end

%VIP
Test=sum((window)>=0.5); 
if Test(2)>Test(1) 
    OP_MV= 2;
else
    OP_MV  =  1; 
end



A(i,:) = [Op_prod,OP_sum,OP_mean,OP_min,OP_max,OP_med,OP_MV];

output = mode(A');



 end

% save A;
% save output;

%% save the output in the excel sheet
filename = 'FinalFusion.xlsx';

writematrix(output',filename,'Sheet',1,'Range','Q5:Q47')

