clc;
clear all;
imageFolder_train = fullfile('result1');
imds_train = imageDatastore(fullfile(imageFolder_train), 'LabelSource', 'foldernames');

a = 45;
b = 315;
r = (b-a).*rand(584,1) + a;
se=ones(3,3);
for n=1:2
    
            c = readimage(imds_train,n);
            targetSize = [450 375];
win1 = centerCropWindow2d(size(c),targetSize);
 u_train = imcrop(c,win1);

            
               
            FileName = sprintf('result1\\%d.jpg',n+2);
            imwrite(u_train,FileName);
    
end
imageFolder_train = fullfile('result1');
imds_train = imageDatastore(fullfile(imageFolder_train), 'LabelSource', 'foldernames');

for n=1:4    
            c = readimage(imds_train,n);
            c=imerode(imerode(imerode(imerode(c,se),se),se),se);
             u_train=c;       
            FileName = sprintf('result1\\%d.jpg',n+4);
            imwrite(u_train,FileName);
    
end

imageFolder_train = fullfile('result1');
imds_train = imageDatastore(fullfile(imageFolder_train), 'LabelSource', 'foldernames');


for n=1:8     
            c = readimage(imds_train,n);
            c=imdilate(imdilate(imdilate(imdilate(imdilate(imdilate(imdilate(imdilate(c,se),se),se),se),se),se),se),se);
             u_train=c;  
            FileName = sprintf('result1\\%d.jpg',n+8);
            imwrite(u_train,FileName);
    
end
