 for i = 1:2 
    TP = 400;
    FP = 49;
    FN = 20;
    TN = 424;

    Accuracy = (TP+TN)./(TP+FP+TN+FN);

    TPR = TP./(TP + FN);%tp/actual positive  RECALL SENSITIVITY
    if isnan(TPR)
        TPR = 0;
    end
    PPV = TP./ (TP + FP); % tp / predicted positive PRECISION
    if isnan(PPV)
        PPV = 0;
    end
    TNR = TN./ (TN+FP); %tn/ actual negative  SPECIFICITY
    if isnan(TNR)
        TNR = 0;
    end
    FPR = FP./ (TN+FP);
    if isnan(FPR)
        FPR = 0;
    end
    FScore = (2*(PPV * TPR)) / (PPV+TPR);

    if isnan(FScore)
        FScore = 0;
    end
 end

fprintf('Accuracy = %2.2f.\n',100*Accuracy);
fprintf('RECALL or SENSITIVITY = %2.2f.\n',100*TPR);
fprintf('PRECISION = %2.2f.\n',100*PPV);
fprintf('SPECIFICITY = %2.2f.\n',100*TNR);
fprintf('F1-Score = %2.2f.\n',100*FScore);