%% Load 
A= 'C:\Users\ALZUBAID\OneDrive - Queensland University of Technology\Desktop\Adersal\DFU\DFU';
parentDir = A;
 dataDir = 'Test-C';
% dataDir = 'TargetDataS';
% more deatils https://au.mathworks.com/help/deeplearning/ug/extract-image-features-using-pretrained-network.html
%%  Divide into Training and Validation Data

Test = imageDatastore(fullfile(parentDir,dataDir),...
    'IncludeSubfolders',true,...
    'LabelSource','foldernames');
  Test.ReadFcn = @customReadDatastoreImage;


%% load the model 
net = XceptionDFUv1;

net.Layers
%analyzeNetwork(net)
%% 
% last FC to extract the features
layer='newDFU';

%%

FeatureTrain = activations(net,allImages,layer,'outputAs','rows');
FeatureTestX = activations(net,Test,layer,'outputAs','rows');

whos FeatureTrain

%%
X1= allImages.Labels; 

T=Test.Labels;


%%

yfit = SVM.predictFcn(FeatureTestX); 

accuracy1 = mean(yfit == T)

%% with label

idx = [9 24 64 270 101 70 210 137 245 426 492 76];
figure
for i = 1:numel(idx)
    subplot(3,4,i)
    I = readimage(Test29,idx(i));
    label = yfit(idx(i));
    imshow(I)
    title(char(label))
end

%% with persentage

idx = [9 24 64 270 101 70 210 137 245 426 492 76];
figure
for i = 1:numel(idx)
    subplot(3,4,i)
    I = readimage(imgsValidation,idx(i));
%     imgsValidation.ReadFcn = @customReadDatastoreImage;
%  [YPred,probs] = classify(xceptionCTatl,I);
 yfit = LinerBS.predictFcn(FeatureTest); 
%     prob = num2str(100*max(predictedLabels(idx(i),:)),2);
    imshow(I)
    label = yfit(idx(i));
title(string(label) + ", " + num2str(100*max(probs),3) + "%");
end







%% 
% Test on Unseen images


A= 'C:\Users\uqlalzub\Desktop\Dr.Ali\TwoNew';
parentDir = A;
dataDir = 'TestSet300';

TestUnseen = imageDatastore(fullfile(parentDir,dataDir),...
    'IncludeSubfolders',true,...
    'LabelSource','foldernames');
 TestUnseen.ReadFcn = @customReadDatastoreImage;
%%
FeatureTestUnseen = activations(net,imgsValidation,layer,'outputAs','rows');
YPredNew = predict(SVM2f,FeatureTestUnseen); 

plotconfusion(imgsValidation.Labels,YPredNew)


%%

YPred = predict(SVM2f,FeatureTest);


%% display

idx = [1 5 10 15];
figure
for i = 1:numel(idx)
    subplot(2,2,i)
    I = readimage(imgsValidation,idx(i));
    label = YPred(idx(i));
    imshow(I)
    title(char(label))
end



%%
function data=customReadDatastoreImage(filename)
% code from default function: 
onState = warning('off', 'backtrace'); 
c = onCleanup(@() warning(onState)); 
data = imread(filename); % added lines: 
data = data(:,:,min(1:3, end)); 
data = imresize(data,[299 299]);
end
