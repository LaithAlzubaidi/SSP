

% camera = webcam; % Connect to the camera
nnet = myNet;  % Load the neural net
nnet.Layers

% analyzeNetwork(nnet)
%%
% while true   
%     picture = camera.snapshot;              % Take a picture  
 picture=imread('e0021.jpg');
      picture = imresize(picture,[80,80]);  % Resize the picture

    label = classify(nnet, picture);        % Classify the picture
       
    image(picture);     % Show the picture
    title(char(label)); % Show the label
%     drawnow;   
% end

%%

 B=imread('image1 (2).png');

 B1 = normalize (B, 'range');
% normImage = mat2gray(picture);
imshow (B1)

img = readimage(allImages,2);
imshow(img)