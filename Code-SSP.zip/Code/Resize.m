% Set the paths to the input and output folders
inputFolder = 'C:\Users\ALZUBAID\OneDrive - Queensland University of Technology\Desktop\New-Orthopedics\Pattren-Recognision\Finger-Done\Test\Finger-Negative'; % Replace with the path to the input images folder
outputFolder = 'C:\Users\ALZUBAID\OneDrive - Queensland University of Technology\Desktop\New-Orthopedics\Pattren-Recognision\Finger-Done\Grad\N';

% Get a list of all image files in the input folder
imageFiles = dir(fullfile(inputFolder, '*.png')); % Change the extension as per your image format

% Create the output folder if it doesn't exist
if ~exist(outputFolder, 'dir')
    mkdir(outputFolder);
end

% Loop through each image file
for i = 1:numel(imageFiles)
    % Read the current image
    imagePath = fullfile(inputFolder, imageFiles(i).name);
    image = imread(imagePath);
    
    % Resize the image to 224x224x3 pixels
    resizedImage = imresize(image, [224, 224]);
    
    % Check if the image has only one color channel (grayscale)
    if size(resizedImage, 3) == 1
        % Convert the grayscale image to RGB by replicating the channel
        resizedImage = repmat(resizedImage, [1, 1, 3]);
    end
    
    % Create the output file name
    [~, name, ext] = fileparts(imageFiles(i).name);
    outputName = [name, '_resized', ext];
    
    % Save the resized image to the output folder
    outputPath = fullfile(outputFolder, outputName);
    imwrite(resizedImage, outputPath);
    
    fprintf('Image %d processed and saved as %s\n', i, outputName);
end
