%% Load
A= 'C:\Users\ALZUBAID\OneDrive - Queensland University of Technology\Desktop\Implant-Shoulder\MRI\Old';
parentDir = A;
 dataDir = 'Testing';
% dataDir = 'TargetDataS';



%%  Divide into Training and Validation Data

allImages = imageDatastore(fullfile(parentDir,dataDir),...
    'IncludeSubfolders',true,...
    'LabelSource','foldernames');
 allImages.ReadFcn = @customReadDatastoreImage;
 disp(['Number of training images: ',num2str(numel(allImages.Files))]);
%  allImages.ReadFcn = @customReadDatastoreImage1;
%% Measure network accuracy
predictedLabels = classify(xceptionMRITL2, allImages); 
accuracy = mean(predictedLabels == allImages.Labels)
%%

%[label,prob3_S] = classify(mobilenetv2Shoulder,imgsValidation);

%save prob3_S
%% confusion metrix 
RE= allImages.Labels;                      
cm = confusionmat(RE, predictedLabels)
%[cm,order] = confusionmat(RE, predictedLabels,'Order',{'Cofield','Depuy','Tornier','Zimmer'}) 
% [cm,order] = confusionmat(RE, predictedLabels,'Order',{'COVID','Non-COVID'})
[cm,order] = confusionmat(RE, predictedLabels,'Order',{'glioma','meningioma','notumor','pituitary'})
cm1= bsxfun (@rdivide, cm, sum(cm,2))
mean(diag(cm1))
cm2 = confusionchart(RE, predictedLabels);
%%
CM3= confusionchart(cm1)
%%
tp_m = diag(cm);

 for i = 1:4 
    TP = tp_m(i);
    FP = sum(cm(:, i), 1) - TP;
    FN = sum(cm(i, :), 2) - TP;
    TN = sum(cm(:)) - TP - FP - FN;

    Accuracy = (TP+TN)./(TP+FP+TN+FN);

    TPR = TP./(TP + FN);%tp/actual positive  RECALL SENSITIVITY
    if isnan(TPR)
        TPR = 0;
    end
    PPV = TP./ (TP + FP); % tp / predicted positive PRECISION
    if isnan(PPV)
        PPV = 0;
    end
    TNR = TN./ (TN+FP); %tn/ actual negative  SPECIFICITY
    if isnan(TNR)
        TNR = 0;
    end
    FPR = FP./ (TN+FP);
    if isnan(FPR)
        FPR = 0;
    end
    FScore = (2*(PPV * TPR)) / (PPV+TPR);

    if isnan(FScore)
        FScore = 0;
    end
 end

fprintf('Accuracy = %2.2f.\n',100*Accuracy);
fprintf('RECALL or SENSITIVITY = %2.2f.\n',100*TPR);
fprintf('PRECISION = %2.2f.\n',100*PPV);
fprintf('SPECIFICITY = %2.2f.\n',100*TNR);
fprintf('F1-Score = %2.2f.\n',100*FScore);


%%
idx = [1 2 66 4 77 160 210 80 119 20 201 130];
figure
for i = 1:numel(idx)
    subplot(3,4,i)
    I = readimage(imgsValidation,idx(i));
%     imgsValidation.ReadFcn = @customReadDatastoreImage;
    label = predictedLabels(idx(i));
%     prob = num2str(100*max(predictedLabels(idx(i),:)),2);
    imshow(I)
    title(char(label))
end



[YPred,probs] = classify(mobilenetv2Shoulder,I);
imshow(I)
label = YPred;
title(string(label) + ", " + num2str(100*max(probs),3) + "%");

%%  

idx = [31 22 300 47 311 1183 95 37 140 20 597 345];
figure
for i = 1:numel(idx)
    subplot(3,4,i)
    I = readimage(allImages,idx(i));
%     imgsValidation.ReadFcn = @customReadDatastoreImage;
 [YPred,probs] = classify(xceptionMRITL2,I);
%     prob = num2str(100*max(predictedLabels(idx(i),:)),2);
    imshow(I)
    label = YPred;
title(string(label) + ", " + num2str(100*max(probs),3) + "%");
end



%%

function data=customReadDatastoreImage(filename)
% code from default function: 
onState = warning('off', 'backtrace'); 
c = onCleanup(@() warning(onState)); 
data = imread(filename); % added lines: 
data = data(:,:,min(1:3, end)); 
data = imresize(data,[299 299]);
end